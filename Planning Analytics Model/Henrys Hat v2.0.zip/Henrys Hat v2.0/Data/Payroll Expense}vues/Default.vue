﻿389,100
390,"Default"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,b:0.#########G|0|
374,2
7,Year
270,2
2020
2021
274,
275,
281,0
282,
7,Version
270,2
Actual
Budget
274,
275,
281,0
282,
360,1
7,Quarter
270,5
Total
Q1
Q2
Q3
Q4
274,
275,
281,0
282,
371,1
7,Payroll Measure
270,12
Hours of Direct Labor Needed
Production Department - Direct Labor
Production Department - Indirect Labor
Administrative Department
Average Salary - Production Department - Direct Labor (USD, per hour)
Average Salary - Production Department - Indirect Labor ('000, per quarter)
Average Salary - Administrative Department ('000, per quarter)
Payroll expense - Production Department - Direct Labor
Payroll expense - Production Department - Indirect Labor
Payroll expense - Administrative Department
Total Payroll expense
Growth %
274,
275,
281,0
282,
373,2
1,2020
1,Actual
372,0
372,00
384,0
385,0
377,4
844
669
1381
1030
378,0
382,255
379,4
0
0
0
0
11,20211123130715
381,0
32,6
null\n
